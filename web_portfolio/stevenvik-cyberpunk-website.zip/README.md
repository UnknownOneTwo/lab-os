# Cyberpunk Portfolio Website

This is a personal portfolio website for Steven Vik, styled in a Cyberpunk 2077 theme.

## Features
- Hero banner with neon effects
- Project showcase
- About and certification sections
- Contact email
- Uses external `cyberpunk.css` theme

## Deployment
Place this under `web_portfolio/` in your GitHub repo or deploy to Hostinger or GitHub Pages.